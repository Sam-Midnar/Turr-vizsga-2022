het = 36

x = int(input("Hány hetet jártunk ebben a tanévben iskolába? "))

if x < 31 and x > 0:
    print(het-x, "hét van még hátra.")
    print("Még van idő javítani!")
elif x >= 32 and x <= het:
    print("Itt az év vége!")
else:
    print("Hibás adatot adott meg!")