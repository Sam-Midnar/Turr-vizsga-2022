class Utazas():
    def __init__(self, cel, napok):
        self.cel=cel
        self.napok=napok
        