import random



vezeteknev = input("Kérem a vezetéknevét! ")
keresztnev = input("Kérem a keresztnevét! ")

def nev (samu):
    return vezeteknev and keresztnev

print("Az előállított felhasználónév:", vezeteknev, keresztnev, random.randint(1,200))
