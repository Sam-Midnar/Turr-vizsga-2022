f = open("legdragabb.txt", "r") 
s = open("iroda.py", "r",)

cel = input("Add meg az utazás célját!")
nap = input("Add meg hány napos az utazás! ")

print(f.read(f))
